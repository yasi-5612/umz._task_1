from django.shortcuts import render

from .models import profile
# Create your views here.

def p1(request):
    stu = profile.objects.get(id=1)
    stu_list = {
        'student' : stu
    }
    return render (request, 'cv/p1.html', stu_list)